﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Minecraft.Mojang.API.Models.Responses
{
    public sealed record PlayerUUID(string id, string name);
}
