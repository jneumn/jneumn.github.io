﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Minecraft.Mojang.API
{
    public static class MojangAuth
    {
        private static readonly ReadOnlyMemory<char> endPoint = "https://authserver.mojang.com/".AsMemory();
        public sealed record MinecraftAgent(string name, int version);
        public sealed record AuthPayload(MinecraftAgent agent, string username, string password, string token = null, bool requestUser = false);

        public sealed record AuthProperty(string name, string value);
        public sealed record AvailableProfile(string name, string id);
        public sealed record SelectedProfile(string name, string id);
        public sealed record MojangUser(string username, AuthProperty[] properties, string id);
        public sealed record MojangAuthResponse(
            MojangUser user,
            string clientToken,
            string accessToken,
            AvailableProfile[] availableProfiles,
            SelectedProfile selectedProfile);

        public static MojangAuthResponse Authenticate(int version, ReadOnlySpan<char> username, ReadOnlySpan<char> password)
        {
            using var client = new HttpClient();
            var request = new HttpRequestMessage(HttpMethod.Post, endPoint + "authenticate")
            {
                Content = new StringContent(
                    JsonSerializer.Serialize(new AuthPayload(
                        new MinecraftAgent("Minecraft", version),
                        username.ToString(),
                        password.ToString())),
                    Encoding.UTF8,
                    "application/json"),
            };

            var response = client.Send(request);
            //if (response.StatusCode != System.Net.HttpStatusCode.NoContent)
            //    throw new Exception("Something went wrong, received unexpected response");

            using var reader = new StreamReader(response.Content.ReadAsStream());
            return JsonSerializer.Deserialize<MojangAuthResponse>(reader.ReadToEnd());
        }
    }
}
