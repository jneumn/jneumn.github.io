﻿
using Minecraft.Mojang.API.Models.Responses;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Numerics;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Unicode;

namespace Minecraft.Mojang.API
{
    public static class ApiUtils
    {
        private static ReadOnlyMemory<char> endPoint = "https://api.mojang.com/".AsMemory();
        public static PlayerUUID[] GetPlayerUUID(ReadOnlySpan<char> name)
        {
            using var client = new HttpClient();
            var request = new HttpRequestMessage(HttpMethod.Post, endPoint + "profiles/minecraft")
            {
                Content = new StringContent( 
                    JsonSerializer.Serialize(name.ToString()),
                    Encoding.UTF8,
                    "application/json"),
            };

            var response = client.Send(request);
            using var reader = new StreamReader(response.Content.ReadAsStream());
            return JsonSerializer.Deserialize<PlayerUUID[]>(reader.ReadToEnd());
        }
        public static ReadOnlyMemory<char> MinecraftShaDigest(ReadOnlySpan<char> input)
        {
            if (input.Length > 16 || input.Length < 3)
                throw new ArgumentException("input has an invalid length");
            Span<byte> buffer = new byte[input.Length]; // I FEAR NOTHING PWAAAAAAAAA
            _ = Encoding.UTF8.GetBytes(input, buffer);

            Span<byte> hash = new byte[256];
            var valid = new SHA1Managed().TryComputeHash(buffer, hash, out int bytesWritten);
            if (!valid)
                throw new Exception("Invalid buffer input for hashing");

            hash = hash.Slice(0, bytesWritten);
            hash.Reverse();

            var bigInteger = new BigInteger(hash);
            if(bigInteger < 0)
            {
                return ("-" + (-bigInteger).ToString("x").TrimStart('0')).AsMemory();
            }
            else
            {
                return bigInteger.ToString("x").TrimStart('0').AsMemory();
            }
        }
    }
}
