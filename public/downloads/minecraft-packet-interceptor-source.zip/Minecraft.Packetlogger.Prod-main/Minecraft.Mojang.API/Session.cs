﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Minecraft.Mojang.API
{
    public static class Session
    {
        private static ReadOnlyMemory<char> endPoint = "https://sessionserver.mojang.com/".AsMemory();
        public record SharedSecretResponse(string accessToken, string playerId, string serverId);
        public sealed record DecryptedSharedSecred(string username, string serverId, string id);
        public static SharedSecretResponse SendSharedClientSecret(ReadOnlySpan<char> hash)
        {
            using var client = new HttpClient();
            var request = new HttpRequestMessage(HttpMethod.Post, endPoint + "session/minecraft/join")
            {
                Content = new StringContent(
                    JsonSerializer.Serialize(hash.ToString()),
                    Encoding.UTF8,
                    "application/json"),
            };

            var response = client.Send(request);
            if (response.StatusCode != System.Net.HttpStatusCode.NoContent)
                throw new Exception("Something went wrong, received unexpected response");

            using var reader = new StreamReader(response.Content.ReadAsStream());
            return JsonSerializer.Deserialize<SharedSecretResponse>(reader.ReadToEnd());
        }
        //public static object SendDecryptedSharedSecret(ReadOnlySpan<char> username, ReadOnlySpan<char> serverId, ReadOnlySpan<char> id)
        //{
        //    using var client = new HttpClient();
        //    var request = new HttpRequestMessage(HttpMethod.Get, endPoint + "session/minecraft/hasJoined")
        //    {
        //        Content = new StringContent(
        //            JsonSerializer.Serialize(hash.ToString()),
        //            Encoding.UTF8,
        //            "application/json"),
        //    };

        //    var response = client.Send(request);
        //    if (response.StatusCode != System.Net.HttpStatusCode.NoContent)
        //        throw new Exception("Something went wrong, received unexpected response");

        //    using var reader = new StreamReader(response.Content.ReadAsStream());
        //    return JsonSerializer.Deserialize<SharedSecretResponse>(reader.ReadToEnd());
        //}
      
    }
}
