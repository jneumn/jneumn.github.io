﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using static Minecraft.Mojang.API.Session;

namespace Minecraft.Mojang.API
{
    public sealed class LegacyAuth
    {
        private static readonly ReadOnlyMemory<char> endPoint = "https://login.minecraft.net/".AsMemory();
        public static void Login(ReadOnlySpan<char> username, ReadOnlySpan<char> sessionId, ReadOnlySpan<char> launcherVersion)
        {
            using var client = new HttpClient();
            var request = new HttpRequestMessage(HttpMethod.Post, endPoint + $"session?name={username.ToString()}&session={sessionId.ToString()}&version={launcherVersion.ToString()}");
            request.Headers.Add("Content-Type", "application/x-www-form-urlencoded");
            var response = client.Send(request);
            if (response.StatusCode != System.Net.HttpStatusCode.NoContent)
                throw new Exception("Something went wrong, received unexpected response");

            using var reader = new StreamReader(response.Content.ReadAsStream());
        }
        public static void SendKeepAlive(ReadOnlySpan<char> username, ReadOnlySpan<char> sessionId)
        {
            using var client = new HttpClient();
            var request = new HttpRequestMessage(HttpMethod.Post, endPoint + $"session?name={username.ToString()}&session={sessionId.ToString()}");
            request.Headers.Add("Content-Type", "application/x-www-form-urlencoded");
            var response = client.Send(request);
            if (response.StatusCode != System.Net.HttpStatusCode.NoContent)
                throw new Exception("Something went wrong, received unexpected response");

            using var reader = new StreamReader(response.Content.ReadAsStream());
        }
    }
}
