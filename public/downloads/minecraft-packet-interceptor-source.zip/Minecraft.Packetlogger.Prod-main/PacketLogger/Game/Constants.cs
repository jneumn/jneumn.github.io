namespace MCIHateStreams
{
    public static class Constants
    {
        public const string TargetHostname = "localhost";
        public const ushort TargetPort = 25565;
        public const string Username = "YOUR_USERNAME";
        public const string Password = "YOUR_PASSWORD";
    }
}
