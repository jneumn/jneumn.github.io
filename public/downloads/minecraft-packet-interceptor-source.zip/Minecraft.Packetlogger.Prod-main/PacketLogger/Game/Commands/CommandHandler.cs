﻿namespace MCIHateStreams.Game.Commands
{
    internal static class CommandHandler
    {
        private static readonly Dictionary<string, ICommand> commands = new Dictionary<string, ICommand>();
        static CommandHandler()
        {
            foreach(var type in typeof(CommandHandler).Assembly.GetTypes())
            {
                if(type.IsClass && type.GetInterfaces().Contains(typeof(ICommand)))
                {
                    var newCommand = (ICommand?)Activator.CreateInstance(type);
                    commands.Add(newCommand!.Name, newCommand);
                }
            }
        }
        // TODO: Fix split of input
        public static void Execute(Stream @from, Stream to, MinecraftContext context, string input)
        {
            if (!commands.TryGetValue(input, out ICommand? command))
                return;

            command.Execute(@from, to, context, input.Split(' ').AsSpan());
        }
    }
}
