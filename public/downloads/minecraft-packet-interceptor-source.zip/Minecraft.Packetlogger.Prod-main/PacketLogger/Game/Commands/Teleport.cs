﻿namespace MCIHateStreams.Game.Commands
{
    internal class Teleport : ICommand
    {
        public string Name => "teleport";

        public void Execute(Stream from, Stream to, MinecraftContext context, ReadOnlySpan<string> command)
        {
            if (!double.TryParse(command[0], out double x))
                return;
            if (!double.TryParse(command[1], out double y))
                return;
            if (!double.TryParse(command[2], out double z))
                return;

            _ = context.PlayerData.MoveTowards(context, context.PlayerData.X + x, context.PlayerData.Y + y, context.PlayerData.Z + z);
        }
    }
}
