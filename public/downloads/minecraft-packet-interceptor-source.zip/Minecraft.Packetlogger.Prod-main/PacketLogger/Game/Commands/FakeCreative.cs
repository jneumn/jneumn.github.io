﻿namespace MCIHateStreams.Game.Commands
{
    internal sealed class FakeCreative : ICommand
    {
        public string Name => "creative";

        public void Execute(Stream from, Stream to, MinecraftContext context, ReadOnlySpan<string> command)
        {
            using var mem = new MemoryStream();
            NetworkUtils.WriteVarInt(mem, 0x1E);
            NetworkUtils.WriteByte(mem, 3);
            NetworkUtils.WriteFloat(mem, 1);
            context.ClientWriteSemaphore.Wait();
            NetworkUtils.WritePacket(context.CompressionThreshold, context!.ToClientStream!, mem);
            context.ClientWriteSemaphore.Release();
        }
    }
}
