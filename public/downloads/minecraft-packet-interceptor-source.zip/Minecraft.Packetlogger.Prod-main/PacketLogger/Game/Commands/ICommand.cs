﻿namespace MCIHateStreams.Game.Commands
{
    internal interface ICommand
    {
        public string Name { get; }
        public void Execute(Stream @from, Stream to, MinecraftContext context, ReadOnlySpan<string> command);
    }
}
