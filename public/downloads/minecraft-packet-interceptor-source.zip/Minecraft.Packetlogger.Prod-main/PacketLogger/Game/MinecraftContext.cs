﻿using System.Net.Sockets;

namespace MCIHateStreams
{
    public sealed class MinecraftContext
    {
        public string UserUUID;
        public int CompressionThreshold { get; set; } = -1;
        public ConnectionState State { get; set; }
        public SemaphoreSlim LoginSemaphore { get; } = new SemaphoreSlim(1, 1);
        public Socket? ToServerSocket { get; set; }
        public Socket? ToClientSocket { get; set; }
        public Stream? ToServerStreamWrite { get; set; }
        public Stream? ToServerStreamRead { get; set; }
        public Stream? ToClientStream { get; set; }
        public string? AccessToken { get; set; }
        public PlayerData PlayerData { get; set; } = new PlayerData();
        public List<int> TeleportIdsToIgnore { get; set; } = new List<int>();
        public SemaphoreSlim ClientWriteSemaphore { get; } = new SemaphoreSlim(1, 1);
        public SemaphoreSlim ServerWriteSemaphore { get; } = new SemaphoreSlim(1, 1);
    }

    public sealed class PlayerData
    {
        public double X;
        public double Y;
        public double Z;
        public float Pitch;
        public float Yaw;
        public bool OnGround;

        public void SetPositionAndRotation(MinecraftContext context, double x, double y, double z, float pitch, float yaw, bool onGround = false)
        {
            this.X = x;
            this.Y = y;
            this.Z = z;
            this.Pitch = pitch;
            this.Yaw = yaw;
            this.OnGround = onGround;

            using var mem1 = new MemoryStream();
            NetworkUtils.WriteVarInt(mem1, 0x12);
            NetworkUtils.WriteDouble(mem1, x);
            NetworkUtils.WriteDouble(mem1, y);
            NetworkUtils.WriteDouble(mem1, z);
            NetworkUtils.WriteFloat(mem1, pitch);
            NetworkUtils.WriteFloat(mem1, yaw);
            NetworkUtils.WriteBool(mem1, true);
            context.ServerWriteSemaphore.Wait();
            NetworkUtils.WritePacket(context.CompressionThreshold, context.ToServerStreamWrite, mem1);
            context.ServerWriteSemaphore.Release();

            using var mem2 = new MemoryStream();
            NetworkUtils.WriteVarInt(mem2, 0x38);
            NetworkUtils.WriteDouble(mem2, x);
            NetworkUtils.WriteDouble(mem2, y);
            NetworkUtils.WriteDouble(mem2, z);
            NetworkUtils.WriteFloat(mem2, pitch);
            NetworkUtils.WriteFloat(mem2, yaw);
            NetworkUtils.WriteByte(mem2, 0);
            var tpId = Random.Shared.Next();
            context.TeleportIdsToIgnore.Add(tpId);
            NetworkUtils.WriteVarInt(mem2, tpId);
            NetworkUtils.WriteBool(mem2, onGround);
            context.ClientWriteSemaphore.Wait();
            NetworkUtils.WritePacket(context.CompressionThreshold, context.ToClientStream, mem2);
            context.ClientWriteSemaphore.Release();
        }

        public void SetPosition(MinecraftContext context, double x, double y, double z, bool onGround = false)
        {
            this.X = x;
            this.Y = y;
            this.Z = z;
            this.OnGround = onGround;

            using var mem1 = new MemoryStream();
            NetworkUtils.WriteVarInt(mem1, 0x11);
            NetworkUtils.WriteDouble(mem1, x);
            NetworkUtils.WriteDouble(mem1, y);
            NetworkUtils.WriteDouble(mem1, z);
            NetworkUtils.WriteBool(mem1, true);
            context.ServerWriteSemaphore.Wait();
            NetworkUtils.WritePacket(context.CompressionThreshold, context.ToServerStreamWrite, mem1);
            context.ServerWriteSemaphore.Release();

            using var mem2 = new MemoryStream();
            NetworkUtils.WriteVarInt(mem2, 0x38);
            NetworkUtils.WriteDouble(mem2, x);
            NetworkUtils.WriteDouble(mem2, y);
            NetworkUtils.WriteDouble(mem2, z);
            NetworkUtils.WriteFloat(mem2, 0);
            NetworkUtils.WriteFloat(mem2, 0);
            NetworkUtils.WriteByte(mem2, 0x08 | 0x10);

            var tpId = Random.Shared.Next();
            context.TeleportIdsToIgnore.Add(tpId);
            NetworkUtils.WriteVarInt(mem2, tpId);
            NetworkUtils.WriteBool(mem2, onGround);
            context.ClientWriteSemaphore.Wait();
            NetworkUtils.WritePacket(context.CompressionThreshold, context.ToClientStream, mem2);
            context.ClientWriteSemaphore.Release();
        }

        public async Task MoveTowards(MinecraftContext context, double x, double y, double z)
        {
            await Task.Yield();

            int i = 0;
            while (Math.Abs(this.X - x) > 0.5 || Math.Abs(this.Y - y) > 0.5 || Math.Abs(this.Z - z) > 0.5)
            {
                if (i++ > 20)
                    break;

                while (context.TeleportIdsToIgnore.Count > 0)
                {
                    Console.WriteLine("Waiting for teleport to complete...");
                    await Task.Delay(10);
                }

                var xDiff = x - this.X;
                var yDiff = y - this.Y;
                var zDiff = z - this.Z;

                Console.WriteLine($"({X}, {Y}, {Z}) + ({xDiff}, {yDiff}, {zDiff})");

                xDiff = Math.Min(Math.Max(xDiff, -1.5), 1.5);
                yDiff = Math.Min(Math.Max(yDiff, -1.5), 1.5);
                zDiff = Math.Min(Math.Max(zDiff, -1.5), 1.5);

                SetPosition(context, X + xDiff, Y + yDiff, Z + zDiff, false);
                await Task.Delay(200);
            }
        }
    }
}
