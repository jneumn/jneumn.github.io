﻿namespace MCIHateStreams
{
    public enum ConnectionState
    {
        Handshake,
        Login,
        Status,
        Play
    }
}
