﻿using System.Buffers.Binary;
using System.IO.Compression;
using System.Text;

namespace MCIHateStreams
{
    public static class NetworkUtils
    {
        public static void WritePacket(int compressionThreshold, Stream to, MemoryStream data)
        {
            if (compressionThreshold < 0)
            {
                WriteVarInt(to, (int)data.Position);
                data.Position = 0;
                data.CopyTo(to);
            }
            else if (data.Position < compressionThreshold)
            {
                WriteVarInt(to, (int)data.Position + 1);
                WriteVarInt(to, 0);
                data.Position = 0;
                data.CopyTo(to);
            }
            else
            {
                var d = (int)data.Position;
                using var compressedBackingStream = new MemoryStream();
                WriteVarInt(compressedBackingStream, d);
                using var zlibStream = new ZLibStream(compressedBackingStream, CompressionLevel.Fastest, true);
                data.Position = 0;
                data.CopyTo(zlibStream);
                zlibStream.Flush();
                WriteVarInt(to, (int)compressedBackingStream.Position);
                compressedBackingStream.Position = 0;
                compressedBackingStream.CopyTo(to);
            }
        }

        public static void WriteArray<T>(this Stream stream, T[] val, Action<Stream, T> action)
        {
            for (int i = 0; i < val.Length; i++)
                action(stream, val[i]);
        }

        public static void WriteArray<T>(this Stream stream, T[] val, Func<Stream, T, ValueTask> func)
        {
            for (int i = 0; i < val.Length; i++)
                func(stream, val[i]);
        }

        public static void WriteVarInt(this Stream stream, int val)
        {
            var size = 0;
            var v = val;
            while ((v & -0x80) != 0)
            {
                if (size > 5)
                    throw new IOException("VarInt too long, its just, i can't handle that");

                stream.WriteByte((byte)(v & 0x7F | 0x80));
                v = (int)(((uint)v) >> 7);
                size++;
            }

            stream.WriteByte((byte)v);
        }

        public static void WriteString(this Stream stream, string val)
        {
            var bytes = Encoding.UTF8.GetBytes(val);
            WriteVarInt(stream, bytes.Length);
            if (bytes.Length > 0)
                stream.Write(bytes, 0, bytes.Length);
        }

        public static void WriteBool(this Stream stream, bool val)
            => WriteByte(stream, val ? (byte)0x01 : (byte)0x00);

        public static void WriteByte(this Stream stream, byte val)
        {
            stream.WriteByte(val);
        }

        public static void WriteUShort(this Stream stream, ushort val)
        {
            var buff = new byte[2];
            BinaryPrimitives.WriteUInt16BigEndian(buff.AsSpan(), val);
            stream.Write(buff, 0, buff.Length);
        }

        public static void WriteInt(this Stream stream, int val)
        {
            var buff = new byte[4];
            BinaryPrimitives.WriteInt32BigEndian(buff.AsSpan(), val);
            stream.Write(buff, 0, buff.Length);
        }

        public static void WriteULong(this Stream stream, ulong val)
        {
            var buff = new byte[8];
            BinaryPrimitives.WriteUInt64BigEndian(buff.AsSpan(), val);
            stream.Write(buff, 0, buff.Length);
        }

        public static void WriteLong(this Stream stream, long val)
        {
            var buff = new byte[8];
            BinaryPrimitives.WriteInt64BigEndian(buff.AsSpan(), val);
            stream.Write(buff, 0, buff.Length);
        }

        // public static void WriteBlockPosition(Stream stream, BlockPosition pos)
        //     => WriteLong(stream, ((((long)pos.X) & 0x3FFFFFF) << 38) | ((((long)pos.Y) & 0xFFF) << 26) | (((long)pos.Z) & 0x3FFFFFF));

        public static void WriteFloat(this Stream stream, float val)
        {
            var v = BitConverter.SingleToInt32Bits(val);
            WriteInt(stream, v);
        }

        public static void WriteDouble(this Stream stream, double val)
        {
            var v = BitConverter.DoubleToInt64Bits(val);
            WriteLong(stream, v);
        }

        public static int ReadVarInt(this Stream stream)
        {
            var val = 0;
            var size = 0;
            int readData;
            while (((readData = stream.ReadByte()) & 0x80) == 0x80)
            {
                if (readData == -1)
                    throw new EndOfStreamException();

                val |= (readData & 0x7F) << (size++ * 7);
                if (size > 5)
                {
                    throw new IOException("VarInt too long. Hehe that's punny.");
                }
            }

            return val | ((readData & 0x7F) << (size * 7));
        }

        public static string ReadString(this Stream stream)
        {
            var length = ReadVarInt(stream);
            var buff = new byte[length];
            stream.Read(buff, 0, buff.Length);
            return Encoding.UTF8.GetString(buff.AsSpan());
        }

        public static bool ReadBool(this Stream stream)
        {
            var b = ReadByte(stream);
            if (b == 0x01)
                return true;
            if (b == 0x00)
                return false;
            throw new InvalidDataException("boolean can only be 0x00 or 0x01");
        }

        public static byte ReadByte(this Stream stream)
        {
            var i = stream.ReadByte();
            if (i == -1)
                throw new EndOfStreamException();
            return (byte)i;
        }

        public static ushort ReadUShort(this Stream stream)
        {
            var buff = new byte[2];
            stream.Read(buff, 0, buff.Length);
            return BinaryPrimitives.ReadUInt16BigEndian(buff.AsSpan());
        }

        public static int ReadInt(this Stream stream)
        {
            var buff = new byte[4];
            stream.Read(buff, 0, buff.Length);
            return BinaryPrimitives.ReadInt32BigEndian(buff.AsSpan());
        }

        public static ulong ReadULong(this Stream stream)
        {
            var buff = new byte[8];
            stream.Read(buff, 0, buff.Length);
            return BinaryPrimitives.ReadUInt64BigEndian(buff.AsSpan());
        }

        public static long ReadLong(this Stream stream)
        {
            var buff = new byte[8];
            stream.Read(buff, 0, buff.Length);
            return BinaryPrimitives.ReadInt64BigEndian(buff.AsSpan());
        }

        // public static void<BlockPosition> ReadBlockPosition(Stream stream)
        // {
        //     var val = ReadLong(stream);
        // 
        //     var x = val >> 38;
        //     var y = (val >> 26) & 0xFFF;
        //     var z = val << 38 >> 38;
        //     return new BlockPosition()
        //     {
        //         X = (int)x,
        //         Y = (int)y,
        //         Z = (int)z,
        //     };
        // }

        public static float ReadFloat(this Stream stream)
        {
            var v = ReadInt(stream);
            return BitConverter.Int32BitsToSingle(v);
        }

        public static double ReadDouble(this Stream stream)
        {
            var v = ReadLong(stream);
            return BitConverter.Int64BitsToDouble(v);
        }

        // internal static int ReadVarIntWithLegacyCheck(Stream stream)
        // {
        //     var val = 0;
        //     var size = 0;
        //     int readData;
        //     while (((readData = stream.ReadByte()) & 0x80) == 0x80)
        //     {
        //         if (readData == -1)
        //             throw new EndOfStreamException();
        // 
        //         if (size == 0 && readData == 0xFE)
        //             throw new LegacyServerListPingException();
        // 
        //         val |= (readData & 0x7F) << (size++ * 7);
        //         if (size > 5)
        //         {
        //             throw new IOException("VarInt too long. Hehe that's punny.");
        //         }
        //     }
        // 
        //     return val | ((readData & 0x7F) << (size * 0x7));
        // }
    }
}
