﻿namespace MCIHateStreams
{
    public interface IServerToClientHook : IPacketHook
    {

    }
}
