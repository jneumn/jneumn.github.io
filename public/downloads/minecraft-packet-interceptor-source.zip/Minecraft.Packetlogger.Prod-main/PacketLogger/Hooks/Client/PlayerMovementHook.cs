﻿namespace MCIHateStreams.C2SHooks
{
    public sealed class PlayerMovementHook : IClientToServerHook
    {
        public int PacketId => 0x14;
        public ConnectionState State => ConnectionState.Play;
        public bool Execute(Stream @from, Stream to, MinecraftContext context)
        {
            var onGround = NetworkUtils.ReadBool(from);

            context.PlayerData.OnGround = onGround;
            NetworkUtils.WriteBool(to, onGround);

            return false;
        }
    }
}
