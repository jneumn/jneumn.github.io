﻿using System.Text;

namespace MCIHateStreams.C2SHooks
{
    public sealed class PluginMessageC2SHook : IClientToServerHook
    {
        public int PacketId => 0x0A;
        public ConnectionState State => ConnectionState.Play;
        public bool Execute(Stream @from, Stream to, MinecraftContext context)
        {
            var channel = NetworkUtils.ReadString(from);
            var data = from.ReadExactly((int)(@from.Length - @from.Position));
            Console.WriteLine($"C2S {channel} {data.Length}: \"{Encoding.UTF8.GetString(data)}\"");

            switch (channel)
            {
                case "MC|Brand":
                    NetworkUtils.WriteString(to, "MC|Brand");
                    to.Write(Encoding.UTF8.GetBytes($"Proxied {Encoding.UTF8.GetString(data)}"));
                    break;
                default:
                    NetworkUtils.WriteString(to, channel);
                    to.Write(data);
                    break;
            }

            return false;
        }
    }
}
