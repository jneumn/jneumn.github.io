﻿namespace MCIHateStreams.C2SHooks
{
    public class PlayerRotationHook : IClientToServerHook
    {
        public int PacketId => 0x13;
        public ConnectionState State => ConnectionState.Play;
        public bool Execute(Stream @from, Stream to, MinecraftContext context)
        {
            var yaw = NetworkUtils.ReadFloat(from);
            var pitch = NetworkUtils.ReadFloat(from);
            var onGround = NetworkUtils.ReadBool(from);

            context.PlayerData.Yaw = yaw;
            context.PlayerData.Pitch = pitch;
            context.PlayerData.OnGround = onGround;

            NetworkUtils.WriteFloat(to, yaw);
            NetworkUtils.WriteFloat(to, pitch);
            NetworkUtils.WriteBool(to, onGround);

            return false;
        }
    }
}
