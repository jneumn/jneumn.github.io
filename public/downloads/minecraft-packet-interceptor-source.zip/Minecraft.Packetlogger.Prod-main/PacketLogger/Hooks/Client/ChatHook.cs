﻿using MCIHateStreams.Game.Commands;

namespace MCIHateStreams.C2SHooks
{
    public sealed class ChatHook : IClientToServerHook
    {
        public int PacketId => 0x03;
        public ConnectionState State => ConnectionState.Play;
        public bool Execute(Stream @from, Stream to, MinecraftContext context)
        {
            var message = NetworkUtils.ReadString(from);

            if (message.StartsWith('.'))
            {
                CommandHandler.Execute(from, to, context, message);

                Console.WriteLine($"Detected Command {message}");
                if (message == ".creative")
                {
                    using var mem = new MemoryStream();
                    NetworkUtils.WriteVarInt(mem, 0x1E);
                    NetworkUtils.WriteByte(mem, 3);
                    NetworkUtils.WriteFloat(mem, 1);
                    context.ClientWriteSemaphore.Wait();
                    NetworkUtils.WritePacket(context.CompressionThreshold, context.ToClientStream!, mem);
                    context.ClientWriteSemaphore.Release();
                }
                else if (message.StartsWith(".setpos"))
                {
                    var segments = message.Split(' ');
                    var x = int.Parse(segments[1]);
                    var y = int.Parse(segments[2]);
                    var z = int.Parse(segments[3]);

                    _ = context.PlayerData.MoveTowards(context, context.PlayerData.X + x, context.PlayerData.Y + y, context.PlayerData.Z + z);
                }
            }
            else
            {
                NetworkUtils.WriteString(to, message);
            }

            return false;
        }
    }
}
