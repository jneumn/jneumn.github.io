﻿using Minecraft.Mojang.API;

namespace MCIHateStreams.C2SHooks
{
    public sealed class HandshakeHook : IClientToServerHook
    {
        public int PacketId => 0x00;
        public ConnectionState State => ConnectionState.Handshake;
        public bool Execute(Stream from, Stream to, MinecraftContext context)
        {
            var protoId = NetworkUtils.ReadVarInt(from);
            var address = NetworkUtils.ReadString(from);
            var port = NetworkUtils.ReadUShort(from);
            var nextState = NetworkUtils.ReadVarInt(from);

            var authResult = MojangAuth.Authenticate(protoId, Constants.Username, Constants.Password);
            context.AccessToken = authResult.accessToken;
            context.UserUUID = authResult.selectedProfile.id;

            NetworkUtils.WriteVarInt(to, protoId);
            NetworkUtils.WriteString(to, Constants.TargetHostname); // tcpshields bypass wow
            NetworkUtils.WriteUShort(to, Constants.TargetPort);
            NetworkUtils.WriteVarInt(to, nextState);

            switch (nextState)
            {
                case 1:
                    context.State = ConnectionState.Status;
                    break;
                case 2:
                    context.State = ConnectionState.Login;
                    break;
                default:
                    throw new ArgumentException($"Invalid State {nextState}");
            }

            return false;
        }
    }
}
