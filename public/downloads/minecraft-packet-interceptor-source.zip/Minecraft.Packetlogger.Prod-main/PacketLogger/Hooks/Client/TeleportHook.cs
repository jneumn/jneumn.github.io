﻿namespace MCIHateStreams.C2SHooks
{
    public sealed class TeleportHook : IClientToServerHook
    {
        public int PacketId => 0x00;
        public ConnectionState State => ConnectionState.Play;
        public bool Execute(Stream @from, Stream to, MinecraftContext context)
        {
            var id = NetworkUtils.ReadVarInt(from);

            var index = context.TeleportIdsToIgnore.IndexOf(id);
            if (index != -1)
                context.TeleportIdsToIgnore.RemoveAt(index);
            else
                NetworkUtils.WriteVarInt(to, id);

            return false;
        }
    }
}
