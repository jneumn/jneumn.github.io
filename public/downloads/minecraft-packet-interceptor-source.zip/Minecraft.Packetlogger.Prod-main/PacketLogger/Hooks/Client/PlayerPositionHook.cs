﻿namespace MCIHateStreams.C2SHooks
{
    public sealed class PlayerPositionHook : IClientToServerHook
    {
        public int PacketId => 0x11;
        public ConnectionState State => ConnectionState.Play;
        public bool Execute(Stream @from, Stream to, MinecraftContext context)
        {
            var x = NetworkUtils.ReadDouble(from);
            var y = NetworkUtils.ReadDouble(from);
            var z = NetworkUtils.ReadDouble(from);
            var onGround = NetworkUtils.ReadBool(from);

            context.PlayerData.X = x;
            context.PlayerData.Y = y;
            context.PlayerData.Z = z;
            context.PlayerData.OnGround = onGround;

            NetworkUtils.WriteDouble(to, x);
            NetworkUtils.WriteDouble(to, y);
            NetworkUtils.WriteDouble(to, z);
            NetworkUtils.WriteBool(to, onGround);

            return false;
        }
    }
}
