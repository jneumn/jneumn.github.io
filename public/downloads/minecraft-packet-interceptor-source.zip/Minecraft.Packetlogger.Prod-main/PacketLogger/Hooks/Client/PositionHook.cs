﻿namespace MCIHateStreams.C2SHooks
{
    public sealed class PositionHook : IClientToServerHook
    {
        public int PacketId => 0x06;
        public ConnectionState State => ConnectionState.Play;
        public bool Execute(Stream from, Stream to, MinecraftContext context)
        {
            var x = NetworkUtils.ReadDouble(from);
            var feetY = NetworkUtils.ReadDouble(from);
            var z = NetworkUtils.ReadDouble(from);
            var yaw = NetworkUtils.ReadFloat(from);
            var pitch = NetworkUtils.ReadFloat(from);
            var onGround = NetworkUtils.ReadBool(from);

            Console.WriteLine($"Read PosRot: {x} {feetY} {z} {yaw} {pitch} {onGround}");

            NetworkUtils.WriteDouble(to, x);
            NetworkUtils.WriteDouble(to, feetY);
            NetworkUtils.WriteDouble(to, z);
            NetworkUtils.WriteFloat(to, yaw);
            NetworkUtils.WriteFloat(to, pitch);
            NetworkUtils.WriteBool(to, onGround);

            return false;
        }
    }
}
