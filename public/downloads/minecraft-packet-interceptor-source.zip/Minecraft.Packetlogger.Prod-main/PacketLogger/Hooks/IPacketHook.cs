﻿namespace MCIHateStreams
{
    public interface IPacketHook
    {
        int PacketId { get; }
        ConnectionState State { get; }
        bool Execute(Stream from, Stream to, MinecraftContext context);
    }
}
