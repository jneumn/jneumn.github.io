﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MCIHateStreams.Hooks.Server
{
    internal sealed class EntityUpdatePositionAndRotation : IServerToClientHook
    {
        public int PacketId => 0x2A;

        public ConnectionState State => ConnectionState.Play;

        public bool Execute(Stream @from, Stream to, MinecraftContext context)
        {
            var entityId = from.ReadVarInt();

            var dX = from.ReadUShort();
            var dY = from.ReadUShort();
            var dZ = from.ReadUShort();

            var yaw = from.ReadFloat();
            var pitch = from.ReadFloat();
            var onGround = from.ReadBool();

            return false;
        }
    }
}
