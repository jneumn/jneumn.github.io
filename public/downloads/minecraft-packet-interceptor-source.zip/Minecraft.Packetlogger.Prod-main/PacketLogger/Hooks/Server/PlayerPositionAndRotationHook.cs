﻿namespace MCIHateStreams.S2CHooks
{
    public sealed class PlayerPositionAndRotationHook : IServerToClientHook
    {
        public int PacketId => 0x38;
        public ConnectionState State => ConnectionState.Play;
        public bool Execute(Stream @from, Stream to, MinecraftContext context)
        {
            var x = NetworkUtils.ReadDouble(from);
            var y = NetworkUtils.ReadDouble(from);
            var z = NetworkUtils.ReadDouble(from);
            var yaw = NetworkUtils.ReadFloat(from);
            var pitch = NetworkUtils.ReadFloat(from);
            var flags = NetworkUtils.ReadByte(from);
            var teleportId = NetworkUtils.ReadVarInt(from);
            var dismount = NetworkUtils.ReadBool(from);

            if ((flags & 0x01) == 0x01)
                context.PlayerData.X += x;
            else
                context.PlayerData.X = x;

            if ((flags & 0x02) == 0x02)
                context.PlayerData.Y += y;
            else
                context.PlayerData.Y = y;

            if ((flags & 0x04) == 0x04)
                context.PlayerData.Z += z;
            else
                context.PlayerData.Z = z;

            if ((flags & 0x08) == 0x08)
                context.PlayerData.Yaw += yaw;
            else
                context.PlayerData.Yaw = yaw;

            if ((flags & 0x10) == 0x10)
                context.PlayerData.Pitch += pitch;
            else
                context.PlayerData.Pitch = pitch;

            NetworkUtils.WriteDouble(to, x);
            NetworkUtils.WriteDouble(to, y);
            NetworkUtils.WriteDouble(to, z);
            NetworkUtils.WriteFloat(to, yaw);
            NetworkUtils.WriteFloat(to, pitch);
            NetworkUtils.WriteByte(to, flags);
            NetworkUtils.WriteVarInt(to, teleportId);
            NetworkUtils.WriteBool(to, dismount);

            return false;
        }
    }
}
