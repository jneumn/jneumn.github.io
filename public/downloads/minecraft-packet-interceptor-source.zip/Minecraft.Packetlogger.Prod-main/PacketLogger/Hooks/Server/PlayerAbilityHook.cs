﻿namespace MCIHateStreams.S2CHooks
{
    public sealed class PlayerAbilityHook : IServerToClientHook
    {
        public int PacketId => 0x32;
        public ConnectionState State => ConnectionState.Play;
        public bool Execute(Stream @from, Stream to, MinecraftContext context)
        {
            var flags = NetworkUtils.ReadByte(from);
            var flyingSpeed = NetworkUtils.ReadFloat(from);
            var fovMul = NetworkUtils.ReadFloat(from);

            NetworkUtils.WriteByte(to, (byte)(flags | 0x01 | 0x04));
            NetworkUtils.WriteFloat(to, flyingSpeed);
            NetworkUtils.WriteFloat(to, fovMul);

            return false;
        }
    }
}
