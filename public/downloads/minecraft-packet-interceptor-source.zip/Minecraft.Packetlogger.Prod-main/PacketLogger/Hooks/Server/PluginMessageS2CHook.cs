﻿using System.Text;

namespace MCIHateStreams.S2CHooks
{
    public sealed class PluginMessageS2CHook : IServerToClientHook
    {
        public int PacketId => 0x18;
        public ConnectionState State => ConnectionState.Play;
        public bool Execute(Stream @from, Stream to, MinecraftContext context)
        {
            var channel = NetworkUtils.ReadString(from);
            var data = from.ReadExactly((int)(@from.Length - @from.Position));
            Console.WriteLine($"S2C {channel} {data.Length}: \"{Encoding.UTF8.GetString(data)}\"");

            switch (channel)
            {
                case "MC|Brand":
                case "minecraft:brand":
                    NetworkUtils.WriteString(to, channel);
                    to.Write(Encoding.UTF8.GetBytes($"Proxied {Encoding.UTF8.GetString(data)}"));
                    break;
                default:
                    NetworkUtils.WriteString(to, channel);
                    to.Write(data);
                    break;
            }
            return false;
        }
    }
}
