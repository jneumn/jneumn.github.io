﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MCIHateStreams.Hooks.Server
{
    /// <summary>
    /// This packet is sent by the server when an entity moves less then 8 blocks; if an entity moves more than 8 blocks Entity Teleport should be sent instead.
    /// </summary>
    internal sealed class EntityUpdatePosition : IServerToClientHook
    {
        public int PacketId => 0x29;

        public ConnectionState State => ConnectionState.Play;
  
        public bool Execute(Stream @from, Stream to, MinecraftContext context)
        {
            var entityId = from.ReadVarInt();

            var dX = from.ReadUShort(); 
            var dY = from.ReadUShort();
            var dZ = from.ReadUShort();

            return false;
        }
    }
}
