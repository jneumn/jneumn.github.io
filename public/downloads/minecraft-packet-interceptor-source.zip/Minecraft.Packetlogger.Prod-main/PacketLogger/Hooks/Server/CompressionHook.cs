﻿namespace MCIHateStreams.S2CHooks
{
    public sealed class CompressionHook : IServerToClientHook
    {
        public int PacketId => 0x03;
        public ConnectionState State => ConnectionState.Login;

        public bool Execute(Stream from, Stream to, MinecraftContext context)
        {
            context.CompressionThreshold = NetworkUtils.ReadVarInt(from);
            Console.WriteLine($"Enabled Compression with Threshold {context.CompressionThreshold}");
            NetworkUtils.WriteVarInt(to, context.CompressionThreshold);
            return false;
        }
    }
}
