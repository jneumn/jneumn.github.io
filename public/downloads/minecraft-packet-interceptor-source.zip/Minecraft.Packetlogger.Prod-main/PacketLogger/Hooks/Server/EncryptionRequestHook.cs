﻿using Alex.Networking.Java.Util.Encryption;
using System.Net;
using System.Net.Http.Json;
using System.Numerics;
using System.Security.Cryptography;
using System.Text;

namespace MCIHateStreams.S2CHooks
{
    public sealed class EncryptionRequestHook : IServerToClientHook
    {
        public int PacketId => 0x01;
        public ConnectionState State => ConnectionState.Login;
        public bool Execute(Stream @from, Stream to, MinecraftContext context)
        {
            var serverId = NetworkUtils.ReadString(from);
            var publicKeyData = from.ReadExactly(NetworkUtils.ReadVarInt(from));
            var verifyToken = from.ReadExactly(NetworkUtils.ReadVarInt(from));
            var secret = RandomNumberGenerator.GetBytes(16);

            string hash;
            using (var memStream = new MemoryStream())
            {
                memStream.Write(Encoding.UTF8.GetBytes(serverId));
                memStream.Write(secret);
                memStream.Write(publicKeyData);
                hash = MinecraftShaDigest(memStream.ToArray());
            }
            Task.Run(async () =>
            {
                using var httpClient = new HttpClient();
                var res = await httpClient.PostAsJsonAsync("https://sessionserver.mojang.com/session/minecraft/join",
                    new { accessToken = context.AccessToken, selectedProfile = context.UserUUID, serverId = hash });
                res.EnsureSuccessStatusCode();
                if (res.StatusCode != HttpStatusCode.NoContent)
                    throw new Exception($"{res.StatusCode} != No Content");
            }).GetAwaiter().GetResult();

            var rsa = RsaHelper.DecodePublicKey(publicKeyData);
            var secretEncrypted = rsa.Encrypt(secret, RSAEncryptionPadding.Pkcs1);
            var verifyEncrypted = rsa.Encrypt(verifyToken, RSAEncryptionPadding.Pkcs1);

            using var data = new MemoryStream();
            NetworkUtils.WriteVarInt(data, 0x01);
            NetworkUtils.WriteVarInt(data, secretEncrypted.Length);
            data.Write(secretEncrypted);
            NetworkUtils.WriteVarInt(data, verifyEncrypted.Length);
            data.Write(verifyEncrypted);

            context.ServerWriteSemaphore.Wait();
            NetworkUtils.WritePacket(context.CompressionThreshold, context.ToServerStreamWrite, data);
            context.ServerWriteSemaphore.Release();

            var aes = Aes.Create();
            aes.Key = secret;
            aes.IV = secret;
            aes.Mode = CipherMode.CFB;
            aes.Padding = PaddingMode.None;

            context.ToServerStreamRead =
                new CryptoStream(context.ToServerStreamRead, aes.CreateDecryptor(), CryptoStreamMode.Read);
            context.ToServerStreamWrite =
                new CryptoStream(context.ToServerStreamWrite, aes.CreateEncryptor(), CryptoStreamMode.Write);
            return false;
        }

        // straight steal from https://gist.github.com/ammaraskar/7b4a3f73bee9dc4136539644a0f27e63
        private static String MinecraftShaDigest(byte[] input)
        {
            var hash = SHA1.HashData(input);
            // Reverse the bytes since BigInteger uses little endian
            Array.Reverse(hash);

            var b = new BigInteger(hash);
            // very annoyingly, BigInteger in C# tries to be smart and puts in
            // a leading 0 when formatting as a hex number to allow roundtripping 
            // of negative numbers, thus we have to trim it off.
            if (b < 0)
            {
                // toss in a negative sign if the interpreted number is negative
                return "-" + (-b).ToString("x").TrimStart('0');
            }
            else
            {
                return b.ToString("x").TrimStart('0');
            }
        }
    }
}
