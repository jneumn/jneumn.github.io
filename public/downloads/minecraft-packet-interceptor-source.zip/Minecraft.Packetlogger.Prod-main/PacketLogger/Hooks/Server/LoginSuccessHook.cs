﻿namespace MCIHateStreams.S2CHooks
{
    public sealed class LoginSuccessHook : IServerToClientHook
    {
        public int PacketId => 0x02;
        public ConnectionState State => ConnectionState.Login;

        public bool Execute(Stream @from, Stream to, MinecraftContext context)
        {
            context.State = ConnectionState.Play;
            return true;
        }
    }
}
