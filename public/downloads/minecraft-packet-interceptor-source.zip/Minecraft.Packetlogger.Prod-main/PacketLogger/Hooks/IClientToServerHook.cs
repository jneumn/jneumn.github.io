﻿namespace MCIHateStreams
{
    public interface IClientToServerHook : IPacketHook
    {

    }
}
