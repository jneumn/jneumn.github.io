﻿using MCIHateStreams;
using MCIHateStreams.C2SHooks;
using MCIHateStreams.S2CHooks;
using System.IO.Compression;
using System.Net;
using System.Net.Sockets;

using var listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
listener.Bind(new IPEndPoint(IPAddress.Any, 25566));
listener.Listen();
Console.WriteLine("Waiting for connection...");
using var client = await listener.AcceptAsync();
Console.WriteLine("Creating connection to server...");
using var serverClient = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
serverClient.Connect(Constants.TargetHostname, Constants.TargetPort);
await using var proxyToServerStream = new NetworkStream(serverClient, false);
await using var clientToProxyStream = new NetworkStream(client, false);

Console.WriteLine("Starting to forward");

var context = new MinecraftContext();
context.ToClientSocket = client;
context.ToClientStream = clientToProxyStream;
context.ToServerSocket = serverClient;
context.ToServerStreamRead = proxyToServerStream;
context.ToServerStreamWrite = proxyToServerStream;

var f1 = Forward(context, "C2S", new IClientToServerHook[]
{
    new HandshakeHook(),
    new PluginMessageC2SHook(),
    new ChatHook(),
    new TeleportHook(),
    new PlayerPositionHook(),
    new PlayerMovementHook(),
    new PlayerRotationHook(),
    new MCIHateStreams.C2SHooks.PlayerPositionAndRotationHook(),
});

var f2 = Forward(context, "S2C", new IServerToClientHook[]
{
    new CompressionHook(),
    new LoginSuccessHook(),
    new EncryptionRequestHook(),
    new PluginMessageS2CHook(),
    new PlayerAbilityHook(),
    new MCIHateStreams.S2CHooks.PlayerPositionAndRotationHook(),
});

await Task.WhenAny(f1, f2);
if (f1.Exception is not null)
{
    Console.WriteLine("In C2S:");
    Console.WriteLine(f1.Exception);
}

if (f2.Exception is not null)
{
    Console.WriteLine("In S2C:");
    Console.WriteLine(f2.Exception);
}
Console.WriteLine("Done");

static async Task Forward(MinecraftContext context, string name, IReadOnlyCollection<IPacketHook> hooks)
{
    var isC2S = name == "C2S";
    var fromSocket = isC2S ? context.ToClientSocket : context.ToServerSocket;
    var toSocket = isC2S ? context.ToServerSocket : context.ToClientSocket;
    var writeSemaphore = isC2S ? context.ServerWriteSemaphore : context.ClientWriteSemaphore;
    while (fromSocket.Connected && toSocket.Connected)
    {
        while (fromSocket.Available <= 0)
            await Task.Delay(20);

        bool semTaken = false;
        if (context.State != ConnectionState.Play)
        {
            await context.LoginSemaphore.WaitAsync();
            semTaken = true;
        }

        try
        {
            var compressionThreshold = context.CompressionThreshold;
            var from = isC2S ? context.ToClientStream : context.ToServerStreamRead;
            var to = isC2S ? context.ToServerStreamWrite : context.ToClientStream;
            var length = NetworkUtils.ReadVarInt(from);
            var data = from.ReadExactly(length);
            Stream payload;
            var packetData = new MemoryStream(data);
            if (compressionThreshold > 0)
            {
                var uncompressedLength = NetworkUtils.ReadVarInt(packetData);
                if (uncompressedLength > 0)
                {
                    payload = new MemoryStream(uncompressedLength);
                    await using var zlibStream = new ZLibStream(packetData, CompressionMode.Decompress, false);
                    await zlibStream.CopyToAsync(payload);
                    payload.Position = 0;
                }
                else
                {
                    payload = packetData;
                }
            }
            else
            {
                payload = packetData;
            }

            var id = NetworkUtils.ReadVarInt(payload);
            // Console.WriteLine($"Found packet {name} {length} 0x{id:x2}");

            bool forward = true;
            await using var forwardData = new MemoryStream();
            NetworkUtils.WriteVarInt(forwardData, id);
            var startForwardPosition = forwardData.Position;
            foreach (var v in hooks.Where(x => x.State == context.State && x.PacketId == id))
            {
                if (!(await Task.Run(() => v.Execute(payload, forwardData, context))))
                    forward = false;
            }

            if (forward)
            {
                await payload.CopyToAsync(forwardData);
            }

            if (forwardData.Position != startForwardPosition)
            {
                await writeSemaphore.WaitAsync();
                NetworkUtils.WritePacket(compressionThreshold, to, forwardData);
                writeSemaphore.Release();
            }

            await payload.DisposeAsync();
        }
        finally
        {
            if (semTaken)
            {
                context.LoginSemaphore.Release();
            }
        }
    }
}